package com.joelson.basicdesign

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.joelson.basicdesign.databinding.ActivityFormBinding

class Form : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ActivityFormBinding: ActivityFormBinding = ActivityFormBinding.inflate(layoutInflater)
        setContentView(ActivityFormBinding.root)
    }
}